
# Simple NFT Minting Website

This project is a basic NFT minting site that allows users to upload an image and mint an NFT. It's fully compatible with Arlink.

## Features
- Upload an image and name for the NFT.
- Simple and clean UI.
- Ready to deploy on Arlink.

## How to Use
1. Upload this repository to GitHub.
2. Deploy the repository on [Arlink](https://arlink.arweave.net/deploy).

Enjoy minting your NFTs!
